import React from 'react';
import { Globe2 } from 'lucide-react';
import { PlanetBody, WorkspaceView } from '../../types/terra';

interface TopCommandBarProps {
  activeView: WorkspaceView;
  onChangeView: (view: WorkspaceView) => void;
  activeBody: PlanetBody;
  onChangeBody: (body: PlanetBody) => void;
  onQuickExport: () => void;
}

const WORKSPACE_TABS: { id: WorkspaceView; label: string }[] = [
  { id: 'overview', label: '3D Overview' },
  { id: 'discovery', label: 'Analog Discovery' },
  { id: 'calendar', label: 'Expedition Calendar' },
  { id: 'lab', label: 'Virtual Field Lab' },
  { id: 'simulator', label: 'CAD Hardware' },
  { id: 'reports', label: 'Synthesis Reports' },
];

export const TopCommandBar: React.FC<TopCommandBarProps> = ({
  activeView,
  onChangeView,
  activeBody,
  onChangeBody,
  onQuickExport,
}) => {
  return (
    <header className="no-print max-w-[1640px] w-full mx-auto px-4 sm:px-6 pt-4 pb-2 shrink-0">
      <div className="bg-[#FFF8F1] rounded-full border border-[#414943]/10 shadow-soft-card px-4 sm:px-5 h-16 flex items-center justify-between gap-3">
        {/* Zone 1: Brand Wordmark + Studio Pill */}
        <button
          type="button"
          onClick={() => onChangeView('overview')}
          className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 cursor-pointer"
        >
          <span className="w-9 h-9 rounded-full bg-[#0F422E] text-[#FFFFFF] flex items-center justify-center shrink-0">
            <Globe2 className="w-4 h-4" />
          </span>
          <span className="flex flex-col leading-none">
            <span className="flex items-center gap-1.5">
              <span className="font-display text-base sm:text-lg font-bold tracking-tight text-[#1D1B17]">
                TERRA-X
              </span>
              <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full bg-[#FEF7EE] border border-[#E69A28]/35 text-[10px] font-semibold text-[#A33E11]">
                Studio
              </span>
            </span>
            <span className="hidden md:block text-[10px] font-medium text-[#696156] mt-0.5">
              Planetary Analogs
            </span>
          </span>
        </button>

        {/* Zone 2: 6-Mode Rounded Pill Navigation */}
        <nav
          aria-label="Workspace views"
          className="flex items-center gap-1 p-1 bg-[#F3EDE5]/90 rounded-full border border-[#414943]/8 overflow-x-auto"
        >
          {WORKSPACE_TABS.map((tab) => {
            const isActive = activeView === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => onChangeView(tab.id)}
                className={`px-3.5 py-2 rounded-full text-xs font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'bg-[#0F422E] text-[#FFFFFF] font-semibold shadow-sm'
                    : 'text-[#414943] hover:text-[#1D1B17] hover:bg-[#FFFFFF]/80'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Planetary Body Switcher + Telemetry Synced + Avatar Monogram */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div
            role="group"
            aria-label="Planetary body selector"
            className="hidden xl:flex items-center gap-0.5 p-1 bg-[#F3EDE5]/90 rounded-full border border-[#414943]/8"
          >
            {(['earth', 'moon', 'mars'] as PlanetBody[]).map((b) => {
              const active = activeBody === b;
              return (
                <button
                  key={b}
                  type="button"
                  onClick={() => onChangeBody(b)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium capitalize transition-all whitespace-nowrap cursor-pointer ${
                    active
                      ? 'bg-[#FFFFFF] text-[#1D1B17] font-semibold shadow-sm'
                      : 'text-[#696156] hover:text-[#1D1B17]'
                  }`}
                >
                  {b}
                </button>
              );
            })}
          </div>

          <button
            type="button"
            onClick={onQuickExport}
            className="hidden sm:inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-[#EAF4EE] text-[#0F422E] border border-[#2A5A44]/20 hover:bg-[#BAEED1]/70 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span className="w-2 h-2 rounded-full bg-[#2A5A44]" aria-hidden="true" />
            <span>Telemetry Synced</span>
          </button>

          <button
            type="button"
            onClick={onQuickExport}
            title="Open Synthesis Reports"
            className="w-9 h-9 rounded-full bg-[#0F422E] hover:bg-[#2A5A44] text-[#FFFFFF] font-display text-xs font-bold flex items-center justify-center shrink-0 transition-colors cursor-pointer"
          >
            TX
          </button>
        </div>
      </div>
    </header>
  );
};
