import React from 'react';
import { Sparkles } from 'lucide-react';
import {
  EarthCandidateSite,
  ObjectiveProfile,
  PlanetaryTarget,
} from '../../types/terra';
import { ProvenanceBadge } from '../common/ProvenanceBadge';

interface TelemetryStripProps {
  target: PlanetaryTarget;
  selectedSite: EarthCandidateSite;
  objective: ObjectiveProfile;
  noveltyOnly: boolean;
}

export const TelemetryStrip: React.FC<TelemetryStripProps> = ({
  target,
  selectedSite,
  objective,
  noveltyOnly,
}) => {
  return (
    <div className="no-print max-w-[1640px] w-full mx-auto px-4 sm:px-6 pb-3 shrink-0">
      <div className="bg-[#FFFFFF]/90 rounded-2xl border border-[#414943]/8 shadow-soft-card px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs text-[#414943]">
        <div className="flex flex-wrap items-center gap-2.5">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#EAF4EE] text-[#0F422E] font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-[#2A5A44]" aria-hidden="true" />
            {objective.shortName} Active
          </span>

          <span className="text-[#696156]">
            Target Datum:{' '}
            <span className="px-2.5 py-0.5 rounded-full bg-[#F3EDE5] text-[#1D1B17] font-semibold">
              {target.name}
            </span>
          </span>

          <span aria-hidden="true" className="text-[#C0C9C1]">
            ·
          </span>

          <span className="font-mono text-[11px] text-[#414943]">
            {target.coordinates}
          </span>

          <span aria-hidden="true" className="text-[#C0C9C1]">
            ·
          </span>

          <span className="font-mono text-[11px] text-[#A33E11] font-medium">
            Grazing Sun {target.solarElevationMinDeg.toFixed(1)}°–
            {target.solarElevationMaxDeg.toFixed(1)}°
          </span>

          <span aria-hidden="true" className="hidden lg:inline text-[#C0C9C1]">
            ·
          </span>

          <span className="hidden lg:inline font-mono text-[11px] text-[#696156]">
            SPICE: {target.spiceKernel}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <span className="px-2.5 py-0.5 rounded-full bg-[#F9F3EB] border border-[#414943]/10 font-mono text-[11px] text-[#1D1B17]">
            Active Analog: <strong>{selectedSite.name.split(' (')[0]}</strong>
          </span>

          {noveltyOnly && (
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#FDF2EC] border border-[#E06A3B]/25 text-[#A33E11] font-semibold text-[11px]">
              <Sparkles className="w-3 h-3" />
              Novelty Engine Active
            </span>
          )}

          <ProvenanceBadge tag={target.provenance} compact />
        </div>
      </div>
    </div>
  );
};
