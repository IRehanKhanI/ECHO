import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Compass,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import {
  DIMENSION_META,
  EARTH_CANDIDATE_SITES,
  MANDATORY_BREAKDOWN_ITEMS,
  MONTH_LABELS,
  OBJECTIVE_PROFILES,
  PLANETARY_TARGETS,
} from '../../data/planetaryData';
import {
  DimensionKey,
  DimensionWeights,
  EarthCandidateSite,
  ObjectiveProfile,
  PlanetaryTarget,
  ScoredCandidate,
} from '../../types/terra';
import { GlobePin, PlanetaryGlobe3D } from '../three/PlanetaryGlobe3D';

interface DiscoveryViewProps {
  activeTarget: PlanetaryTarget;
  onSelectTarget: (targetId: string) => void;
  activeObjective: ObjectiveProfile;
  onSelectObjective: (objectiveId: string) => void;
  weights: DimensionWeights;
  onChangeWeight: (key: DimensionKey, val: number) => void;
  onResetWeights: () => void;
  noveltyOnly: boolean;
  onToggleNovelty: (val: boolean) => void;
  thresholdPct: number;
  onChangeThreshold: (val: number) => void;
  rankedCandidates: ScoredCandidate[];
  selectedSite: EarthCandidateSite;
  onSelectSite: (siteId: string) => void;
  onOpenCalendar: () => void;
}

const SLIDER_DIMENSIONS: DimensionKey[] = [
  'thermalRange',
  'diurnalSeasonalRatio',
  'minTemp',
  'slope',
  'roughness',
  'solarElevation',
  'iceAridity',
  'radarCpr',
];

const SLIDER_DOT_COLOR: Record<DimensionKey, string> = {
  thermalRange: 'bg-[#E06A3B]',
  diurnalSeasonalRatio: 'bg-[#2A5A44]',
  minTemp: 'bg-[#D9822B]',
  slope: 'bg-[#D9822B]',
  roughness: 'bg-[#696156]',
  solarElevation: 'bg-[#E69A28]',
  iceAridity: 'bg-[#0F422E]',
  radarCpr: 'bg-[#A33E11]',
};

export const DiscoveryView: React.FC<DiscoveryViewProps> = ({
  activeTarget,
  onSelectTarget,
  activeObjective,
  onSelectObjective,
  weights,
  onChangeWeight,
  onResetWeights,
  noveltyOnly,
  onToggleNovelty,
  thresholdPct,
  onChangeThreshold,
  rankedCandidates,
  selectedSite,
  onSelectSite,
  onOpenCalendar,
}) => {
  const [showAllWeights, setShowAllWeights] = useState(false);
  const [autoRotate, setAutoRotate] = useState(false);

  const selectedScored = useMemo(
    () =>
      rankedCandidates.find((c) => c.site.id === selectedSite.id) ||
      rankedCandidates[0],
    [rankedCandidates, selectedSite.id],
  );

  const selectedRankIdx = useMemo(
    () =>
      Math.max(
        0,
        rankedCandidates.findIndex((c) => c.site.id === selectedScored?.site.id),
      ),
    [rankedCandidates, selectedScored],
  );

  const earthPins: GlobePin[] = useMemo(
    () =>
      rankedCandidates.map((cand, idx) => ({
        id: cand.site.id,
        label: `#${idx + 1} ${cand.site.name.split(' (')[0]}`,
        lat: cand.site.lat,
        lon: cand.site.lon,
        accent: idx === 0 ? 'moss' : cand.site.isCatalogKnown ? 'slate' : 'terracotta',
        active: cand.site.id === selectedScored?.site.id,
        scoreBadge: `${cand.bestMonthScore.toFixed(1)}%`,
      })),
    [rankedCandidates, selectedScored?.site.id],
  );

  const visibleSliders = showAllWeights
    ? SLIDER_DIMENSIONS
    : SLIDER_DIMENSIONS.filter(
        (d) =>
          weights[d] > 0.01 ||
          d === 'thermalRange' ||
          d === 'diurnalSeasonalRatio' ||
          d === 'slope' ||
          d === 'solarElevation',
      );

  const totalWeightSum = SLIDER_DIMENSIONS.reduce(
    (acc, k) => acc + weights[k],
    0,
  );

  const breakdownItems = MANDATORY_BREAKDOWN_ITEMS[activeTarget.body];

  const novelSiteCount = useMemo(
    () => EARTH_CANDIDATE_SITES.filter((s) => !s.isCatalogKnown).length,
    [],
  );

  const transectPaths = useMemo(() => {
    const tVals = activeTarget.crossSectionElevationsM;
    const eVals = selectedSite.transectElevationsM;
    const normalize = (arr: number[]) => {
      const min = Math.min(...arr);
      const max = Math.max(...arr);
      const span = Math.max(1, max - min);
      return arr.map((v, i) => {
        const x = (i / (arr.length - 1)) * 180;
        const y = 56 - 10 - ((v - min) / span) * 38;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      });
    };
    return {
      targetPts: normalize(tVals).join(' '),
      earthPts: normalize(eVals).join(' '),
    };
  }, [activeTarget, selectedSite]);

  const fidelityPct = Math.round(selectedScored?.bestMonthScore ?? 84);
  const ringRadius = 28;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const ringOffset = ringCircumference * (1 - fidelityPct / 100);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr_350px] gap-6 items-start">
      {/* LEFT RAIL: Two separate rounded-3xl cards matching Stitch Light Studio */}
      <div className="flex flex-col gap-6">
        {/* Card 1: Criteria Weights */}
        <section className="bg-[#FFFFFF] rounded-3xl border border-[#414943]/8 shadow-soft-card p-5">
          <div className="flex items-start justify-between gap-2 mb-3">
            <div>
              <h2 className="font-display text-lg font-bold text-[#1D1B17]">
                Criteria Weights
              </h2>
              <p className="text-xs text-[#696156]">
                Balance surface analogy properties
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-[#EAF4EE] text-[#0F422E] font-mono text-[11px] font-semibold shrink-0">
              100% Calibrated
            </span>
          </div>

          {/* Target & Objective Selectors */}
          <div className="grid grid-cols-1 gap-2 mb-3.5">
            <select
              aria-label="Target planetary reference"
              value={activeTarget.id}
              onChange={(e) => onSelectTarget(e.target.value)}
              className="w-full bg-[#F9F3EB] border border-[#414943]/10 rounded-xl px-3 py-2 text-xs font-semibold text-[#1D1B17] focus:outline-none focus:ring-2 focus:ring-[#2A5A44]"
            >
              {PLANETARY_TARGETS.map((t) => (
                <option key={t.id} value={t.id}>
                  Target: {t.name} ({t.body.toUpperCase()})
                </option>
              ))}
            </select>

            <select
              aria-label="Engineering test objective"
              value={activeObjective.id}
              onChange={(e) => onSelectObjective(e.target.value)}
              className="w-full bg-[#F9F3EB] border border-[#414943]/10 rounded-xl px-3 py-2 text-xs font-semibold text-[#0F422E] focus:outline-none focus:ring-2 focus:ring-[#2A5A44]"
            >
              {OBJECTIVE_PROFILES.map((o) => (
                <option key={o.id} value={o.id}>
                  Profile: {o.shortName}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-2.5">
            {visibleSliders.map((dimKey) => {
              const meta = DIMENSION_META[dimKey];
              const pct =
                totalWeightSum > 0
                  ? Math.round((weights[dimKey] / totalWeightSum) * 100)
                  : 0;
              return (
                <div
                  key={dimKey}
                  className="p-3 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8"
                >
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-semibold text-[#1D1B17] flex items-center gap-1.5 truncate">
                      <span
                        className={`w-2 h-2 rounded-full shrink-0 ${SLIDER_DOT_COLOR[dimKey]}`}
                      />
                      <span className="truncate">{meta.shortLabel}</span>
                    </span>
                    <span className="font-mono font-semibold text-[#A33E11] ml-2">
                      {pct}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={weights[dimKey]}
                    onChange={(e) =>
                      onChangeWeight(dimKey, parseFloat(e.target.value))
                    }
                    className={`w-full terra-slider ${
                      dimKey === 'slope' || dimKey === 'minTemp'
                        ? 'amber-thumb'
                        : dimKey === 'thermalRange'
                          ? 'terracotta-thumb'
                          : ''
                    }`}
                    aria-label={`${meta.label} weight`}
                  />
                  <div className="flex items-center justify-between text-[10px] text-[#696156] mt-1.5">
                    <span>Unit: {meta.unit}</span>
                    <span className="font-medium text-[#0F422E]">
                      {pct >= 30 ? 'Priority Primary' : 'Weighted Factor'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between mt-3 pt-2 border-t border-[#414943]/8">
            <button
              type="button"
              onClick={() => setShowAllWeights((s) => !s)}
              className="text-[11px] font-semibold text-[#0F422E] hover:underline cursor-pointer"
            >
              {showAllWeights ? 'Compact Weights' : 'Show All 8 Dimensions'}
            </button>
            <button
              type="button"
              onClick={onResetWeights}
              className="inline-flex items-center gap-1 text-[11px] text-[#696156] hover:text-[#1D1B17] cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>
        </section>

        {/* Card 2: Novelty Discovery */}
        <section className="bg-[#FFFFFF] rounded-3xl border border-[#414943]/8 shadow-soft-card p-5">
          <div className="flex items-start gap-3 mb-3.5">
            <span className="w-9 h-9 rounded-full bg-[#FDF2EC] border border-[#E06A3B]/20 text-[#A33E11] flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-display text-base font-bold text-[#1D1B17]">
                Novelty Discovery
              </h3>
              <p className="text-[11px] text-[#696156]">
                Suppress overused catalog sites
              </p>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8 flex items-center justify-between gap-2 mb-3">
            <div>
              <div className="text-xs font-semibold text-[#1D1B17]">
                Suppress Legacy Sites
              </div>
              <div className="text-[11px] text-[#696156] mt-0.5">
                Hides classic CAFE 2014 field locations
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={noveltyOnly}
              onClick={() => onToggleNovelty(!noveltyOnly)}
              className={`w-11 h-6 rounded-full p-0.5 transition-colors shrink-0 cursor-pointer ${
                noveltyOnly ? 'bg-[#0F422E]' : 'bg-[#C0C9C1]'
              }`}
            >
              <span
                className={`block w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                  noveltyOnly ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#EAF4EE] border border-[#2A5A44]/15 flex items-center justify-between gap-2 mb-3.5">
            <div>
              <div className="text-xs font-semibold text-[#0F422E]">
                Novel Clusters Identified
              </div>
              <div className="text-[11px] text-[#414943] mt-0.5">
                High Puna salars, Tibetan basins, & nunataks
              </div>
            </div>
            <span className="font-display text-2xl font-bold text-[#0F422E] tabular-nums shrink-0">
              {novelSiteCount}
            </span>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="font-medium text-[#1D1B17]">Fidelity Threshold</span>
              <span className="px-2 py-0.5 rounded-full bg-[#EAF4EE] font-mono text-[11px] font-semibold text-[#0F422E]">
                ≥ {thresholdPct.toFixed(1)}%
              </span>
            </div>
            <input
              type="range"
              min={55}
              max={90}
              step={1}
              value={thresholdPct}
              onChange={(e) => onChangeThreshold(parseInt(e.target.value, 10))}
              className="w-full terra-slider"
              aria-label="Fidelity threshold percentage"
            />
            <div className="flex justify-between text-[10px] text-[#696156] mt-1">
              <span>Broad (55%)</span>
              <span>Exact Match (90%)</span>
            </div>
          </div>

          <button
            type="button"
            onClick={onResetWeights}
            className="mt-4 w-full py-2.5 px-3 rounded-full bg-[#F3EDE5] hover:bg-[#EDE5D8] text-[#1D1B17] text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Refresh Pareto Calculation</span>
          </button>
        </section>
      </div>

      {/* CENTER STAGE: Earth Analog Globe Card + 10km Regional Transect Comparison */}
      <div className="flex flex-col gap-6">
        {/* Card 1: Analog Globe 3D */}
        <section className="bg-[#FFFFFF] rounded-3xl border border-[#414943]/8 shadow-soft-card p-5 flex flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#0F422E] text-white text-xs font-semibold">
                <Compass className="w-3.5 h-3.5" />
                Analog Globe 3D
              </span>
              <span className="px-3 py-1.5 rounded-full bg-[#F3EDE5] text-[#414943] text-xs font-medium">
                Geodetic Datum
              </span>
            </div>

            <div className="flex items-center gap-1.5 p-1 rounded-full bg-[#F9F3EB] border border-[#414943]/8">
              <button
                type="button"
                onClick={() => setAutoRotate((r) => !r)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                  autoRotate
                    ? 'bg-[#FFFFFF] text-[#0F422E] font-semibold shadow-sm'
                    : 'text-[#414943] hover:text-[#1D1B17]'
                }`}
              >
                Rotate 3D
              </button>
              <span className="px-2.5 py-1 text-xs font-medium text-[#A33E11]">
                {rankedCandidates.length} Sites
              </span>
            </div>
          </div>

          <div className="h-[430px] relative rounded-3xl overflow-hidden bg-[#FAF7F2] border border-[#414943]/8">
            <PlanetaryGlobe3D
              body="earth"
              layerId={
                activeObjective.id === 'ice_excavation'
                  ? 'permafrost_ice'
                  : activeObjective.id === 'rover_mobility'
                    ? 'srtm_slope'
                    : 'modis_lst'
              }
              layerOpacity={0.74}
              cameraMode="orbit"
              focusLat={selectedScored?.site.lat ?? -25}
              focusLon={selectedScored?.site.lon ?? -68}
              pins={earthPins}
              onPinClick={onSelectSite}
              autoRotate={autoRotate}
            />

            {/* Floating Terrain Elevation Gradient Card */}
            <div className="pointer-events-none absolute bottom-3 left-3 bg-[#FFFFFF] border border-[#414943]/12 rounded-2xl p-3 shadow-soft-card w-56 hidden sm:block">
              <div className="text-[10px] font-semibold uppercase tracking-wider text-[#696156] mb-1.5">
                Terrain Elevation Gradient
              </div>
              <div className="h-2 w-full rounded-full bg-gradient-to-r from-[#2A5A44] via-[#D9822B] to-[#A33E11]" />
              <div className="flex items-center justify-between font-mono text-[10px] text-[#696156] mt-1">
                <span>-500m</span>
                <span>Puna Plateau</span>
                <span>+6,000m</span>
              </div>
            </div>

            {/* Bottom-Right Inspection Focus Pill */}
            <div className="pointer-events-none absolute bottom-3 right-3 bg-[#FFFFFF] border border-[#414943]/12 rounded-full px-3.5 py-1.5 shadow-soft-card text-xs flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#E06A3B]" />
              <span className="text-[#696156]">Inspection Focus:</span>
              <span className="font-semibold text-[#1D1B17]">
                {selectedSite.region}
              </span>
            </div>
          </div>

          {/* Ranked Candidate Quick Switcher Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pt-1">
            {rankedCandidates.map((cand, idx) => {
              const active = cand.site.id === selectedScored?.site.id;
              return (
                <button
                  key={cand.site.id}
                  type="button"
                  onClick={() => onSelectSite(cand.site.id)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs border transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-[#0F422E] text-white border-[#0F422E] shadow-sm'
                      : 'bg-[#F9F3EB] text-[#1D1B17] border-[#414943]/10 hover:border-[#2A5A44]'
                  }`}
                >
                  <span className="font-mono text-[10px] opacity-75">
                    #{idx + 1}
                  </span>
                  <span className="font-medium">
                    {cand.site.name.split(' (')[0]}
                  </span>
                  <span
                    className={`font-mono text-[11px] font-semibold ${
                      active ? 'text-[#BAEED1]' : 'text-[#0F422E]'
                    }`}
                  >
                    {cand.bestMonthScore.toFixed(1)}%
                  </span>
                  {!cand.site.isCatalogKnown && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#E06A3B] text-white font-semibold">
                      Novel
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </section>

        {/* Card 2: 10 km Regional Transect Comparison */}
        <section className="bg-[#FFFFFF] rounded-3xl border border-[#414943]/8 shadow-soft-card p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="font-display text-base font-bold text-[#1D1B17]">
                10 km Regional Transect Comparison
              </h3>
              <p className="text-xs text-[#696156]">
                Smooth synchronized profile alignment across candidate zones
              </p>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#F9F3EB] border border-[#414943]/8 text-xs">
              <span className="inline-flex items-center gap-1.5 text-[#0F422E] font-semibold">
                <span className="w-3 h-0.5 bg-[#0F422E] inline-block" />
                {activeTarget.name}
              </span>
              <span className="text-[#C0C9C1]">|</span>
              <span className="inline-flex items-center gap-1.5 text-[#A33E11] font-semibold">
                <span className="w-3 h-0.5 bg-[#E06A3B] inline-block" />
                #{selectedRankIdx + 1} {selectedSite.name.split(' (')[0]}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-[#1D1B17]">
                  Elevation Relief (Δz)
                </span>
                <span className="px-2 py-0.5 rounded-full bg-[#EAF4EE] font-mono text-[10px] font-semibold text-[#0F422E]">
                  RMS {selectedSite.rmsRoughnessM.toFixed(1)}m
                </span>
              </div>
              <svg viewBox="0 0 180 56" className="w-full h-16">
                <polyline
                  fill="none"
                  stroke="#0F422E"
                  strokeWidth="2.2"
                  strokeDasharray="3 2"
                  points={transectPaths.targetPts}
                />
                <polyline
                  fill="none"
                  stroke="#E06A3B"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                  points={transectPaths.earthPts}
                />
              </svg>
              <div className="flex justify-between font-mono text-[10px] text-[#696156] mt-1">
                <span>0 km (Rim)</span>
                <span>5 km</span>
                <span>10 km (Basin)</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-[#1D1B17]">
                  Diurnal Temperature Wave
                </span>
                <span className="px-2 py-0.5 rounded-full bg-[#FDF2EC] font-mono text-[10px] font-semibold text-[#A33E11]">
                  ΔT = {selectedSite.monthlyDiurnalDeltaK[selectedScored?.bestMonthIndex ?? 0]} K
                </span>
              </div>
              <svg viewBox="0 0 180 56" className="w-full h-16">
                <path
                  d="M0,45 Q45,44 90,14 T180,45"
                  fill="none"
                  stroke="#0F422E"
                  strokeWidth="2.2"
                  strokeDasharray="3 2"
                />
                <path
                  d="M0,48 Q45,42 90,20 T180,48"
                  fill="none"
                  stroke="#E06A3B"
                  strokeWidth="2.4"
                />
              </svg>
              <div className="flex justify-between font-mono text-[10px] text-[#696156] mt-1">
                <span>00:00 (Nadir)</span>
                <span>12:00</span>
                <span>24:00 (End)</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-[#1D1B17]">
                  Slope Rugosity Bins
                </span>
                <span className="px-2 py-0.5 rounded-full bg-[#FEF7EE] font-mono text-[10px] font-semibold text-[#A33E11]">
                  {selectedSite.slopeDeg.toFixed(1)}° vs {activeTarget.meanSlopeDeg.toFixed(1)}°
                </span>
              </div>
              <div className="h-16 flex items-end gap-1.5 pt-2 px-1">
                {[38, 62, 85, 70, 42, 24].map((h, i) => (
                  <div key={i} className="flex-1 flex items-end gap-1 h-full">
                    <div
                      className="flex-1 bg-[#2A5A44]/45 rounded-full"
                      style={{ height: `${Math.max(18, h - (i % 2) * 12)}%` }}
                    />
                    <div
                      className="flex-1 bg-[#E06A3B] rounded-full"
                      style={{
                        height: `${Math.max(18, h - Math.abs(selectedSite.slopeDeg - activeTarget.meanSlopeDeg) * 1.4)}%`,
                      }}
                    />
                  </div>
                ))}
              </div>
              <div className="flex justify-between font-mono text-[10px] text-[#696156] mt-1">
                <span>0–5°</span>
                <span>10–15°</span>
                <span>&gt;20°</span>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* RIGHT INSPECTOR: Prime Match Candidate Report & Circular Fidelity Ring */}
      <aside className="bg-[#FFFFFF] rounded-3xl border border-[#414943]/8 shadow-soft-card p-5 flex flex-col gap-4">
        {selectedScored && (
          <>
            <div className="flex items-center justify-between gap-2">
              <span className="px-3 py-1 rounded-full bg-[#FDF2EC] text-[#A33E11] font-mono text-[11px] font-semibold">
                PRIME MATCH #{selectedRankIdx + 1}
              </span>
              <span className="text-xs font-medium text-[#696156]">
                Candidate Report
              </span>
            </div>

            <div>
              <h2 className="font-display text-2xl font-bold text-[#1D1B17] leading-tight">
                {selectedScored.site.name}
              </h2>
              <p className="text-xs text-[#696156] mt-1">
                {selectedScored.site.region} · {selectedScored.site.country}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8 grid grid-cols-[1fr_auto] gap-y-2 gap-x-3 text-xs">
              <span className="text-[#696156]">Coordinates</span>
              <span className="font-mono text-right text-[#1D1B17] font-medium">
                {selectedScored.site.coordinates}
              </span>
              <span className="text-[#696156]">Elevation</span>
              <span className="font-mono text-right text-[#1D1B17] font-medium">
                {selectedScored.site.elevationM.toLocaleString()} m
              </span>
              <span className="text-[#696156]">Biome Character</span>
              <span className="text-right font-semibold text-[#A33E11]">
                {selectedScored.site.biomeCharacter}
              </span>
            </div>

            {/* Global Fidelity Score Card with Circular Ring Gauge */}
            <div className="p-4 rounded-2xl bg-[#FFFFFF] border border-[#2A5A44]/20 shadow-sm flex items-center justify-between gap-3">
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-[#2A5A44]">
                  Global Fidelity
                </div>
                <div className="font-display text-lg font-bold text-[#1D1B17] leading-tight mt-0.5">
                  {activeTarget.name.split(' ')[0]} Match
                </div>
                <div className="text-[11px] text-[#696156] mt-1">
                  Confidence:{' '}
                  <span className="font-semibold text-[#0F422E]">
                    {fidelityPct >= 80 ? 'High' : fidelityPct >= 68 ? 'Moderate' : 'Low'}
                  </span>{' '}
                  · Mean {selectedScored.annualMeanScore}%
                </div>
              </div>

              <div className="relative w-18 h-18 flex items-center justify-center shrink-0">
                <svg className="w-18 h-18 -rotate-90" viewBox="0 0 68 68">
                  <circle
                    cx="34"
                    cy="34"
                    r={ringRadius}
                    fill="none"
                    stroke="#EAF4EE"
                    strokeWidth="6"
                  />
                  <circle
                    cx="34"
                    cy="34"
                    r={ringRadius}
                    fill="none"
                    stroke="#0F422E"
                    strokeWidth="6"
                    strokeLinecap="round"
                    strokeDasharray={ringCircumference}
                    strokeDashoffset={ringOffset}
                  />
                </svg>
                <span className="absolute font-display text-base font-bold text-[#0F422E] tabular-nums">
                  {fidelityPct}%
                </span>
              </div>
            </div>

            {/* Dimension Overlap Bars */}
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#696156] mb-2.5">
                Dimension Overlap
              </div>
              <div className="flex flex-col gap-3">
                {selectedScored.dimensionBreakdown
                  .filter((d) => d.weight > 0.001)
                  .map((dim) => (
                    <div key={dim.dimension} className="text-xs">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-[#1D1B17] truncate">
                          {dim.label}
                        </span>
                        <span className="font-mono font-bold text-[#A33E11] shrink-0">
                          {dim.score.toFixed(0)}%
                        </span>
                      </div>
                      <div className="h-2 w-full bg-[#EDE5D8] rounded-full mt-1.5 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            dim.score >= 80
                              ? 'bg-[#2A5A44]'
                              : dim.score >= 55
                                ? 'bg-[#D9822B]'
                                : 'bg-[#E06A3B]'
                          }`}
                          style={{ width: `${dim.score}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between font-mono text-[10px] text-[#696156] mt-1">
                        <span>Earth: {dim.earthValueFormatted}</span>
                        <span>Target: {dim.targetValueFormatted}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            {/* Physical Analogy Boundaries */}
            <div className="p-4 rounded-2xl bg-[#FDF2EC] border border-[#E06A3B]/25 text-xs">
              <div className="flex items-center gap-1.5 font-semibold text-[#A33E11] mb-1.5">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Physical Analogy Boundaries</span>
              </div>
              <p className="text-[11px] text-[#696156] mb-2">
                Real-world terrestrial limits to account for before mission planning:
              </p>
              <ul className="space-y-1.5 text-[11px] text-[#414943] leading-snug">
                {breakdownItems.slice(0, 3).map((item) => (
                  <li key={item.pillar} className="flex items-start gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#E06A3B] mt-1.5 shrink-0" />
                    <span>
                      <strong className="text-[#1D1B17]">{item.pillar}:</strong>{' '}
                      <span className="font-mono">
                        {item.earthValue} vs {item.targetValue}
                      </span>
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            <button
              type="button"
              onClick={onOpenCalendar}
              className="w-full py-3.5 px-5 rounded-full bg-[#0F422E] hover:bg-[#2A5A44] text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-float-pill transition-colors cursor-pointer"
            >
              <span>Open Seasonal Calendar</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <div className="flex items-center justify-between text-[11px] pt-1">
              <span className="text-[#696156]">Suggested Expedition Window</span>
              <span className="font-mono font-semibold text-[#0F422E]">
                {selectedScored.windowSummary.startDateLabel} –{' '}
                {selectedScored.windowSummary.endDateLabel}
              </span>
            </div>
          </>
        )}
      </aside>
    </div>
  );
};
