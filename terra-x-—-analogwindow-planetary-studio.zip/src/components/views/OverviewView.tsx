import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Compass,
  Layers,
  MapPin,
  RotateCw,
  Sun,
  ThermometerSnowflake,
} from 'lucide-react';
import {
  DIVINER_SEASONAL_BINS,
  EARTH_CANDIDATE_SITES,
  MONTH_LABELS,
  OBJECTIVE_PROFILES,
  PLANETARY_TARGETS,
  SCIENTIFIC_LAYERS,
} from '../../data/planetaryData';
import {
  EarthCandidateSite,
  ObjectiveProfile,
  PlanetBody,
  PlanetaryTarget,
  ScientificLayerId,
  ScoredCandidate,
} from '../../types/terra';
import { ProvenanceBadge } from '../common/ProvenanceBadge';
import { TerrainPreviewArtwork } from '../common/TerrainPreviewArtwork';
import {
  GlobeCameraMode,
  GlobePin,
  PlanetaryGlobe3D,
} from '../three/PlanetaryGlobe3D';

interface OverviewViewProps {
  activeBody: PlanetBody;
  onChangeBody: (body: PlanetBody) => void;
  activeTarget: PlanetaryTarget;
  onSelectTarget: (targetId: string) => void;
  activeObjective: ObjectiveProfile;
  onSelectObjective: (objectiveId: string) => void;
  activeLayerId: ScientificLayerId;
  onSelectLayer: (layerId: ScientificLayerId) => void;
  seasonalBinIdx: number;
  onChangeSeasonalBin: (idx: number) => void;
  rankedCandidates: ScoredCandidate[];
  selectedSite: EarthCandidateSite;
  onSelectSite: (siteId: string) => void;
  onLaunchDiscovery: () => void;
  onOpenReport: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  activeBody,
  onChangeBody,
  activeTarget,
  onSelectTarget,
  activeObjective,
  onSelectObjective,
  activeLayerId,
  onSelectLayer,
  seasonalBinIdx,
  onChangeSeasonalBin,
  rankedCandidates,
  selectedSite,
  onSelectSite,
  onLaunchDiscovery,
  onOpenReport,
}) => {
  const [layerOpacity, setLayerOpacity] = useState(0.85);
  const [cameraMode, setCameraMode] = useState<GlobeCameraMode>('orbit');
  const [autoRotate, setAutoRotate] = useState(false);
  const [themeSurface, setThemeSurface] = useState<'studio-light' | 'orbital-dark'>(
    'studio-light',
  );

  const bodyLayers = useMemo(
    () => SCIENTIFIC_LAYERS.filter((l) => l.body === activeBody),
    [activeBody],
  );

  const currentLayer = useMemo(
    () =>
      bodyLayers.find((l) => l.id === activeLayerId) ||
      bodyLayers[0] ||
      SCIENTIFIC_LAYERS[0],
    [bodyLayers, activeLayerId],
  );

  const activeBin =
    DIVINER_SEASONAL_BINS[seasonalBinIdx] || DIVINER_SEASONAL_BINS[2];

  const globePins: GlobePin[] = useMemo(() => {
    if (activeBody === 'earth') {
      return EARTH_CANDIDATE_SITES.map((s) => ({
        id: s.id,
        label: s.name.split(' (')[0],
        lat: s.lat,
        lon: s.lon,
        accent: s.isCatalogKnown ? 'moss' : 'terracotta',
        active: s.id === selectedSite.id,
      }));
    }
    return PLANETARY_TARGETS.filter((t) => t.body === activeBody).map((t) => ({
      id: t.id,
      label: t.name,
      lat: t.lat,
      lon: t.lon,
      accent: t.body === 'moon' ? 'moss' : 'terracotta',
      active: t.id === activeTarget.id,
      scoreBadge: `${t.elevationM >= 0 ? '+' : ''}${t.elevationM}m`,
    }));
  }, [activeBody, activeTarget.id, selectedSite.id]);

  const handlePinClick = (pinId: string) => {
    if (activeBody === 'earth') {
      onSelectSite(pinId);
    } else {
      onSelectTarget(pinId);
    }
  };

  const focusLat = activeBody === 'earth' ? selectedSite.lat : activeTarget.lat;
  const focusLon = activeBody === 'earth' ? selectedSite.lon : activeTarget.lon;

  const crossSectionSvg = useMemo(() => {
    const vals = activeTarget.crossSectionElevationsM;
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const span = Math.max(1, max - min);
    const w = 240;
    const h = 48;
    const pts = vals.map((v, i) => {
      const x = (i / (vals.length - 1)) * w;
      const y = h - 8 - ((v - min) / span) * (h - 16);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });
    return {
      polyline: pts.join(' '),
      area: `0,${h} ${pts.join(' ')} ${w},${h}`,
      min,
      max,
    };
  }, [activeTarget]);

  const minTempK = Math.round(
    activeTarget.minTempC + 273.15 + activeBin.tempBiasK * 0.4,
  );
  const maxTempK = Math.round(
    activeTarget.maxTempC + 273.15 + activeBin.tempBiasK * 0.3,
  );

  const topAnalog = rankedCandidates[0];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[310px_1fr_360px] gap-6 items-start">
      {/* LEFT RAIL: Study Region, Objective, Scientific Layers */}
      <aside className="bg-[#FFFFFF] rounded-3xl border border-[#414943]/8 shadow-soft-card p-5 flex flex-col gap-5">
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#696156]">
              Active Study Region
            </span>
            <div className="flex items-center gap-1 p-0.5 bg-[#F3EDE5] rounded-full">
              {(['moon', 'mars', 'earth'] as PlanetBody[]).map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => onChangeBody(b)}
                  className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium capitalize transition-colors cursor-pointer ${
                    activeBody === b
                      ? 'bg-[#0F422E] text-white'
                      : 'text-[#696156] hover:text-[#1D1B17]'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8">
            <select
              aria-label="Select planetary reference site"
              value={activeTarget.id}
              onChange={(e) => onSelectTarget(e.target.value)}
              className="w-full bg-[#FFFFFF] border border-[#414943]/12 rounded-xl px-3 py-2 text-sm font-display font-semibold text-[#1D1B17] focus:outline-none focus:ring-2 focus:ring-[#2A5A44]"
            >
              {PLANETARY_TARGETS.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} ({t.body.toUpperCase()})
                </option>
              ))}
            </select>
            <p className="font-mono text-[11px] text-[#A33E11] font-medium mt-2.5">
              {activeTarget.coordinates} · Elev {activeTarget.elevationM >= 0 ? '+' : ''}
              {activeTarget.elevationM.toLocaleString()} m
            </p>
            <p className="text-xs text-[#414943] mt-1.5 leading-relaxed">
              {activeTarget.summary}
            </p>
          </div>
        </div>

        {/* Primary Field Objective */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#696156]">
              Primary Field Objective
            </span>
            <span className="px-2 py-0.5 rounded-full bg-[#EAF4EE] text-[10px] font-semibold text-[#0F422E]">
              Functional Filter
            </span>
          </div>
          <div className="flex flex-col gap-2">
            {OBJECTIVE_PROFILES.slice(0, 4).map((obj) => {
              const isSelected = obj.id === activeObjective.id;
              return (
                <button
                  key={obj.id}
                  type="button"
                  onClick={() => onSelectObjective(obj.id)}
                  className={`text-left px-3.5 py-2.5 rounded-2xl border transition-all flex items-start justify-between gap-2 cursor-pointer ${
                    isSelected
                      ? 'bg-[#0F422E] text-[#FFFFFF] border-[#0F422E] shadow-sm'
                      : 'bg-[#F9F3EB] text-[#1D1B17] border-[#414943]/8 hover:border-[#2A5A44]/40'
                  }`}
                >
                  <div>
                    <div className="text-xs font-semibold leading-snug">
                      {obj.shortName}
                    </div>
                    <div
                      className={`text-[11px] mt-0.5 ${
                        isSelected ? 'text-[#BAEED1]' : 'text-[#696156]'
                      }`}
                    >
                      {obj.primaryMetricFocus}
                    </div>
                  </div>
                  {isSelected && (
                    <CheckCircle2 className="w-4 h-4 text-[#BAEED1] shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Spectral & DEM Layers */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#696156] flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-[#2A5A44]" />
              Scientific Raster Layer
            </span>
            <span className="font-mono text-[11px] font-semibold text-[#0F422E]">
              {Math.round(layerOpacity * 100)}%
            </span>
          </div>

          <div className="flex flex-col gap-1.5 mb-3">
            {bodyLayers.map((layer) => {
              const active = layer.id === currentLayer.id;
              return (
                <button
                  key={layer.id}
                  type="button"
                  onClick={() => onSelectLayer(layer.id)}
                  className={`flex items-center justify-between px-3 py-2 rounded-2xl border text-left text-xs transition-all cursor-pointer ${
                    active
                      ? 'bg-[#FFFFFF] border-[#2A5A44] text-[#0F422E] font-semibold shadow-sm'
                      : 'bg-[#F9F3EB] border-[#414943]/8 text-[#414943] hover:text-[#1D1B17]'
                  }`}
                >
                  <span className="truncate">{layer.name}</span>
                  <span className="font-mono text-[10px] opacity-80 ml-2 shrink-0">
                    {layer.resolution.split(' ')[0]}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8">
            <div className="flex items-center justify-between text-[11px] text-[#414943] mb-2">
              <span className="font-medium">Overlay Blend</span>
              <span className="font-mono font-semibold text-[#1D1B17]">
                {Math.round(layerOpacity * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0.15}
              max={1}
              step={0.05}
              value={layerOpacity}
              onChange={(e) => setLayerOpacity(parseFloat(e.target.value))}
              className="w-full terra-slider"
              aria-label="Scientific layer opacity"
            />
            <div className="mt-3 pt-2.5 border-t border-[#414943]/10">
              <div className="flex items-center justify-between text-[10px] font-medium text-[#414943] mb-1.5">
                <span>{currentLayer.shortName}</span>
                <span className="font-mono">{currentLayer.unit}</span>
              </div>
              <div
                className="h-2 w-full rounded-full"
                style={{
                  background: `linear-gradient(90deg, ${currentLayer.rampColors.join(', ')})`,
                }}
              />
              <div className="flex items-center justify-between font-mono text-[10px] text-[#696156] mt-1.5">
                <span>{currentLayer.minLabel}</span>
                <span>{currentLayer.maxLabel}</span>
              </div>
            </div>
          </div>

          {currentLayer.caveat && (
            <p className="mt-2.5 text-[11px] text-[#543300] bg-[#FEF7EE] border border-[#E69A28]/30 rounded-2xl p-2.5 leading-snug">
              Dataset Caveat: {currentLayer.caveat}
            </p>
          )}
        </div>

        <button
          type="button"
          onClick={onLaunchDiscovery}
          className="w-full py-3 px-4 rounded-full bg-[#E06A3B] hover:bg-[#A33E11] text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer"
        >
          <span>Launch Analog Discovery</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </aside>

      {/* CENTER STAGE: 3D Planetary Globe + Orbital Rings + Cross-Section */}
      <section className="bg-[#FFFFFF] rounded-3xl border border-[#414943]/8 shadow-soft-card p-5 flex flex-col gap-4">
        {/* Top Floating Controls Row */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="px-3 py-1 rounded-full bg-[#0F422E] text-white text-xs font-semibold capitalize">
              {activeBody} 3D Workspace
            </span>
            <span className="px-2.5 py-1 rounded-full bg-[#F9F3EB] text-[#414943] font-mono text-[11px]">
              {currentLayer.resolution}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center p-1 bg-[#F3EDE5] rounded-full border border-[#414943]/8">
              {(
                [
                  { id: 'orbit', label: '3D Orbit' },
                  { id: 'polar', label: 'Polar View' },
                  { id: 'relief', label: 'Oblique Relief' },
                ] as { id: GlobeCameraMode; label: string }[]
              ).map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setCameraMode(m.id)}
                  className={`px-3 py-1 rounded-full text-[11px] font-medium transition-all whitespace-nowrap cursor-pointer ${
                    cameraMode === m.id
                      ? 'bg-[#FFFFFF] text-[#0F422E] font-semibold shadow-sm'
                      : 'text-[#696156] hover:text-[#1D1B17]'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setAutoRotate((r) => !r)}
              title="Toggle orbital rotation"
              className={`p-2 rounded-full border text-xs transition-colors cursor-pointer ${
                autoRotate
                  ? 'bg-[#0F422E] text-white border-[#0F422E]'
                  : 'bg-[#F3EDE5] text-[#414943] border-[#414943]/10 hover:text-[#1D1B17]'
              }`}
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() =>
                setThemeSurface((s) =>
                  s === 'studio-light' ? 'orbital-dark' : 'studio-light',
                )
              }
              className="px-3 py-1.5 rounded-full text-[11px] font-medium bg-[#F3EDE5] text-[#414943] border border-[#414943]/10 hover:text-[#1D1B17] whitespace-nowrap cursor-pointer"
            >
              {themeSurface === 'studio-light' ? 'Space Backdrop' : 'Light Studio'}
            </button>
          </div>
        </div>

        {/* 3D Globe Stage with Subtle Concentric Orbital Rings */}
        <div className="relative h-[540px] rounded-3xl overflow-hidden bg-[#FAF7F2] border border-[#414943]/8">
          <PlanetaryGlobe3D
            body={activeBody}
            layerId={currentLayer.id}
            layerOpacity={layerOpacity}
            cameraMode={cameraMode}
            focusLat={focusLat}
            focusLon={focusLon}
            pins={globePins}
            onPinClick={handlePinClick}
            autoRotate={autoRotate}
            themeSurface={themeSurface}
          />

          {/* Subtle orbital ring overlays */}
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="w-[410px] h-[410px] rounded-full border border-[#414943]/8 hidden sm:block" />
          </div>

          {/* Top-Left Grazing Illumination Chip */}
          <div className="pointer-events-none absolute top-4 left-4 bg-[#FFFFFF] border border-[#414943]/12 rounded-2xl px-3.5 py-2 shadow-soft-card">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-[#696156]">
              Solar Geometry & Ephemeris
            </div>
            <div className="font-mono text-xs font-semibold text-[#1D1B17] mt-0.5">
              Grazing Angle {activeTarget.solarElevationMinDeg.toFixed(1)}°–
              {activeTarget.solarElevationMaxDeg.toFixed(1)}° · Bin{' '}
              {seasonalBinIdx + 1}
            </div>
          </div>

          {/* Bottom-Left Elevation / Layer Scale Legend */}
          <div className="pointer-events-none absolute bottom-4 left-4 bg-[#FFFFFF] border border-[#414943]/12 rounded-2xl p-3 shadow-soft-card w-56 hidden sm:block">
            <div className="text-[10px] font-semibold uppercase tracking-wider text-[#696156] mb-1.5">
              {currentLayer.shortName}
            </div>
            <div
              className="h-2 w-full rounded-full"
              style={{
                background: `linear-gradient(90deg, ${currentLayer.rampColors.join(', ')})`,
              }}
            />
            <div className="flex items-center justify-between font-mono text-[10px] text-[#414943] mt-1">
              <span>{currentLayer.minLabel}</span>
              <span>{currentLayer.maxLabel}</span>
            </div>
          </div>

          {/* Bottom-Right Cross-Section (A–B) */}
          <div className="pointer-events-none absolute bottom-4 right-4 bg-[#FFFFFF] border border-[#414943]/12 rounded-2xl p-3.5 shadow-soft-card w-64 hidden sm:block">
            <div className="flex items-center justify-between text-[11px] mb-1">
              <span className="font-semibold text-[#1D1B17]">
                Cross-Section (A–B)
              </span>
              <span className="font-mono font-semibold text-[#A33E11]">
                {crossSectionSvg.max >= 0 ? '+' : ''}
                {crossSectionSvg.max}m / {crossSectionSvg.min}m
              </span>
            </div>
            <svg viewBox="0 0 240 48" className="w-full h-12 overflow-visible">
              <polygon
                fill="rgba(224, 106, 59, 0.14)"
                points={crossSectionSvg.area}
              />
              <polyline
                fill="none"
                stroke="#E06A3B"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={crossSectionSvg.polyline}
              />
            </svg>
          </div>
        </div>

        {/* Bottom Epoch Timeline & Provenance Bar */}
        <div className="pt-1 flex flex-wrap items-center justify-between gap-3 text-[11px]">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <span className="text-[#696156] font-medium shrink-0 mr-1">
              Diviner Seasonal Bin:
            </span>
            {DIVINER_SEASONAL_BINS.map((bin, idx) => (
              <button
                key={bin.id}
                type="button"
                onClick={() => onChangeSeasonalBin(idx)}
                className={`px-2.5 py-1 rounded-full font-mono text-[10px] transition-colors whitespace-nowrap cursor-pointer ${
                  seasonalBinIdx === idx
                    ? 'bg-[#0F422E] text-white font-semibold'
                    : 'bg-[#F3EDE5] text-[#414943] hover:text-[#1D1B17]'
                }`}
              >
                Bin {idx + 1}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 text-[#696156] font-mono text-[10px]">
            <span>SOURCE: {currentLayer.source}</span>
            <span>·</span>
            <span>EPOCH: {currentLayer.epoch}</span>
          </div>
        </div>
      </section>

      {/* RIGHT INSPECTOR: Geological Dossier & Top Matched Analogs */}
      <aside className="bg-[#FFFFFF] rounded-3xl border border-[#414943]/8 shadow-soft-card p-5 flex flex-col gap-5">
        <div className="flex items-start justify-between gap-2">
          <div>
            <span className="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#A33E11]">
              Geological Dossier
            </span>
            <h2 className="font-display text-2xl font-bold text-[#1D1B17] leading-tight mt-0.5">
              {activeBody === 'earth' ? selectedSite.name : activeTarget.name}
            </h2>
          </div>
          <span className="font-mono text-[10px] font-semibold px-2.5 py-1 rounded-full bg-[#FDF2EC] text-[#A33E11] border border-[#E06A3B]/25 shrink-0">
            {activeTarget.classLabel}
          </span>
        </div>

        {/* 2x2 Physical Telemetry Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8">
            <div className="flex items-center justify-between text-[11px] text-[#696156]">
              <span>Min Surface T</span>
              <ThermometerSnowflake className="w-3.5 h-3.5 text-[#2A5A44]" />
            </div>
            <div className="font-display text-2xl font-bold text-[#A33E11] mt-1.5 tabular-nums">
              {activeTarget.minTempC}°C
            </div>
            <div className="font-mono text-[11px] text-[#696156] mt-0.5">
              {minTempK} K (Bin {seasonalBinIdx + 1})
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8">
            <div className="flex items-center justify-between text-[11px] text-[#696156]">
              <span>Max Surface T</span>
              <Sun className="w-3.5 h-3.5 text-[#E06A3B]" />
            </div>
            <div className="font-display text-2xl font-bold text-[#E06A3B] mt-1.5 tabular-nums">
              {activeTarget.maxTempC}°C
            </div>
            <div className="font-mono text-[11px] text-[#696156] mt-0.5">
              {maxTempK} K (Solar Peak)
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8">
            <div className="flex items-center justify-between text-[11px] text-[#696156]">
              <span>Baseline Slope</span>
              <Compass className="w-3.5 h-3.5 text-[#2A5A44]" />
            </div>
            <div className="font-display text-xl font-bold text-[#1D1B17] mt-1.5 tabular-nums">
              {activeTarget.meanSlopeDeg.toFixed(1)}°
            </div>
            <div className="font-mono text-[11px] text-[#696156] mt-0.5">
              RMS {activeTarget.rmsRoughnessM.toFixed(2)} m
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8">
            <div className="flex items-center justify-between text-[11px] text-[#696156]">
              <span>Grazing Solar</span>
              <MapPin className="w-3.5 h-3.5 text-[#D9822B]" />
            </div>
            <div className="font-display text-xl font-bold text-[#1D1B17] mt-1.5 tabular-nums">
              {activeTarget.solarElevationMinDeg.toFixed(1)}°–
              {activeTarget.solarElevationMaxDeg.toFixed(1)}°
            </div>
            <div className="font-mono text-[11px] text-[#696156] mt-0.5">
              CPR {activeTarget.radarCpr.toFixed(2)}
            </div>
          </div>
        </div>

        {/* Top Matched Earth Analogs */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#696156]">
              Top Matched Earth Analogs
            </span>
            <span className="text-[11px] font-semibold text-[#0F422E]">
              Top 3 Sites
            </span>
          </div>

          <div className="flex flex-col gap-2.5">
            {rankedCandidates.slice(0, 3).map((cand, idx) => {
              const isSelected = cand.site.id === selectedSite.id;
              return (
                <button
                  key={cand.site.id}
                  type="button"
                  onClick={() => onSelectSite(cand.site.id)}
                  className={`text-left p-3 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#FFFFFF] border-[#2A5A44] shadow-sm'
                      : 'bg-[#F9F3EB] border-[#414943]/8 hover:border-[#2A5A44]/40'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-[#1D1B17] truncate">
                      {idx + 1}. {cand.site.name}
                    </span>
                    <span className="font-mono text-[11px] font-semibold text-[#0F422E] bg-[#EAF4EE] px-2.5 py-0.5 rounded-full shrink-0">
                      {cand.bestMonthScore.toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-[#696156] mt-1">
                    <span className="truncate">{cand.site.biomeCharacter}</span>
                    <span className="font-mono text-[#A33E11] font-medium shrink-0 ml-2">
                      {MONTH_LABELS[cand.bestMonthIndex]}
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-[#EDE5D8] rounded-full mt-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        idx === 0 ? 'bg-[#2A5A44]' : 'bg-[#E06A3B]'
                      }`}
                      style={{ width: `${Math.min(100, cand.bestMonthScore)}%` }}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Terrain Match Reference Preview */}
        {topAnalog && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-semibold tracking-[0.08em] uppercase text-[#696156]">
                Terrain Match Reference
              </span>
              <span className="font-mono text-[10px] text-[#696156]">
                {selectedSite.coordinates}
              </span>
            </div>
            <TerrainPreviewArtwork
              siteId={selectedSite.id}
              siteName={selectedSite.name}
              badgeText={selectedSite.name.split(' (')[0]}
              scoreText={`${(rankedCandidates.find((c) => c.site.id === selectedSite.id)?.bestMonthScore ?? topAnalog.bestMonthScore).toFixed(1)}% Match`}
              heightClass="h-28"
            />
          </div>
        )}

        {/* Mineralogy & Dataset Provenance */}
        <div className="p-3.5 rounded-2xl bg-[#F9F3EB] border border-[#414943]/8 text-xs">
          <div className="flex items-center justify-between mb-1.5">
            <span className="font-semibold text-[#1D1B17]">
              Lithology & Context
            </span>
            <ProvenanceBadge tag={activeTarget.provenance} compact />
          </div>
          <p className="text-[#414943] leading-relaxed">
            {activeTarget.mineralogyNote}
          </p>
          <p className="font-mono text-[10px] text-[#696156] mt-1.5">
            {activeTarget.sourceDataset}
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenReport}
          className="w-full py-3 px-4 rounded-full border-2 border-[#2A5A44] text-[#0F422E] hover:bg-[#0F422E] hover:text-white text-xs font-semibold transition-colors cursor-pointer"
        >
          Open Analog Fidelity Dossier
        </button>
      </aside>
    </div>
  );
};
